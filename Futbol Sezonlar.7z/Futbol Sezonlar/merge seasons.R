#https://www.kaggle.com/datasets/ahmetfurkandemr/superlig-sezonlari?resource=download


library(tidyverse)

dir_nm <- "~/Projects/ISLR/Data/TFF Data"

seasons<-
dir(path = dir_nm) |> 
  tibble() |> 
  rename_with(~"folder_nm") |> 
  mutate(csv_filename = str_c(dir_nm, "/",folder_nm ,"/", folder_nm, ".csv")) 


read_csv_season <- function(folder_nm, csv_filename){
  read_csv(csv_filename, show_col_types = FALSE) |> 
    mutate(Sezon = folder_nm)  |> 
    arrange(desc(Puan)) |> 
    mutate(Rank = row_number(), .before =Takim_adi )
}


glimpse(seasons)

map2(seasons$folder_nm, seasons$csv_filename, read_csv_season) |> 
  bind_rows() |> 
  arrange(Sezon, Rank) |> 
  write_csv("~/Projects/ISLR/Data/Futbol Sezonlar/1990_2021_Futbol_Sezonlar.csv")
  



